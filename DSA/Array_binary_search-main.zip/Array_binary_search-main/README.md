# Array_binary_search
Array binary search Algo
